# Advanced Gear-CDDA-Mod
Large collection of extreme endgame gear, vehicle parts, weapons, tools, and crafting.  Requires large amounts of rare resources to begin, gets easier as you progress.

Can add to an existing world by modifying the save's mods.json and adding "adv_gear" to the list, with a comma behind every entry except the last.