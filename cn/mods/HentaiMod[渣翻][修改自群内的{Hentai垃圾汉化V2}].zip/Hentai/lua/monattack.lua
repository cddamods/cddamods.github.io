--[[主にモンスターの特殊攻撃関連の処理を記述する。]]--
local body_part_texts = {
	"脸部", "嘴唇", "耳朵", "手指", "手", "手臂", "胸部", "下腹", "腿间", "屁股", "大腿内侧", "腿部", "脚部"
}

local action_texts = {
	"抚摸。",
	"反复抚摸。",
	"轻轻捏了一下。",
	"玩弄。",
	"亲吻了一下。",
	"爬上了舌头。",
	"舔了一下。",
	"吮吸。",
	"吐出一口热气。"
}

--[[デバッグ用ファンクション]]--
function matk_hello(monster)
--function matk_hello(monster, target)
	--NOTE:LUA拡張版DDAはtarget引数を持つmonster_attackが無いっぽいので、monster:attack_target()で攻撃対象を取得している
	local target = monster:attack_target()

	game.add_msg("...who?")

	if (target == nil) then
		game.add_msg("who!?")
	else
		game.add_msg("Ah, it's you, "..target:disp_name().."!")
		game.add_msg(monster:disp_name()..":Hello, "..target:disp_name().."!")
	end

end

--[[↓こっから共通処理↓]]--


--没。
----[[視界内に存在するすべてのCreatureのtripointリストを取得する。]]--
--function search_critters_pos(me, min_range, max_range, force_visible)
--
--	local tripoint_list = {}
--	local center = me:pos()
--
--	--ひどいネストだ...
--	for ix = center.x + (-1 * max_range), center.x + max_range do
--
--		if (ix <= -1 * min_range or ix >= min_range) then
--
--			for iy = center.y + (-1 * max_range), center.y + max_range do
--
--				if (iy <= -1 * min_range or iy >= min_range) then
--					local point = tripoint(ix, iy, center.z)
--
--					if (force_visible or me:sees(point)) then
--						local someone = g:critter_at(point)
--						if (not someone == nil) then
--							table.insert(tripoint_list, point)
--						end
--					end
--				end
--			end
--		end
--	end
--
--	return tripoint_list
--end
--
--function search_critters(me, min_range, max_range, force_visible)
--
--	local critter_list = {}
--
--	local critter_pos_list = search_critters_pos(me, min_range, max_range, force_visible)
--
--	for key, value in pairs(critter_pos_list) do
--		--DEBUG.add_msg("key:"..key)
--		--DEBUG.add_msg("value:"..value.x..", "..value.y)
--		table.insert(critter_list, value)
--	end
--
--	return critter_list
--
--end

--[[monsterが攻撃しようとしているターゲットが射程距離内にいるかどうか判定し、可能な場合はCreatureを返す。]]--
function get_attackable_target(monster, max_range)
	--攻撃しようとしているターゲットを取得
	local someone = monster:attack_target()

	if (someone == nil) then
		--DEBUG.add_msg("Um... never mind.")
		return
	end

	--DEBUG.add_msg("check distance ->")

	--ターゲットとの距離が最大射程よりも離れていたら何もしない
	local dist = game.distance(monster:posx(), monster:posy(), someone:posx(), someone:posy())		--line.cppを参照。
	if (dist > max_range) then
		--DEBUG.add_msg("Out of range.")
		return
	end
	--DEBUG.add_msg("OK!")

	--DEBUG.add_msg("Target is YOU, "..someone:disp_name().."!")

	return someone
end

function get_attackable_chara(monster, max_range)
	local target = get_attackable_target(monster, max_range)

	--PlayerかNPCだけを対象とする。
	if (target == nil or target:is_monster()) then
		--DEBUG.add_msg("not Character? Oh...")
		return
	end

	--NOTE:monster:attack_target()で取得できるのはCreatureクラスなのでCharacterクラスを取り直してやる
	--local ret = g:character_at(target:pos())
	if target:is_player() then
		return player
	end
	local ret = game.get_npc_at(target:pos())

	return ret
end

function get_attackable_player(monster, max_range)
	local target = get_attackable_target(monster, max_range)

	--PlayerかNPCだけを対象とする。
	if (target == nil or target:is_monster()) then
		--DEBUG.add_msg("not Character? Oh...")
		return
	end

	--NOTE:monster:attack_target()で取得できるのはCreatureクラスなのでPlayerクラスを取り直してやる
	--local ret = g:player_at(target:pos())
	if target:is_player() then
		return player
	end
	local ret = game.get_npc_at(target:pos())

	return ret
end

--[[四捨五入。実数numを、小数idp桁で丸める。ネットの拾い物]]
function math.round(num, idp)
	if (idp and idp > 0) then
		local mult = 10^idp
		return math.floor(num * mult + 0.5) / mult
	end
	return math.floor(num + 0.5)
end

--[[ハートマークの二次曲線（いわゆるLove Formura）のtripointを計算する。ネットの拾い物]]
--[[
	NOTE:CDDAの仕様として、マップの横軸xと縦軸yは
	0-->x	右へ行くほど増
	|
	V
	y		下へ行くほど増
	の関係になっているため、数学的な二次曲線グラフとはy軸を反転して考えてやる必要がある。
]]
function LoveFormula(center, radius)
	--DEBUG.add_msg("LoveFormula:start")

	local tripoint_list = {}
	--local center = player:pos()
	--DEBUG.add_msg("center:"..center.x.."/"..center.y)

	local y
	local b = 0.6				--ハート曲線の曲がり具合。0だと完全な円になる。
	local dx = 1 / radius		--xのループカウント刻み
	local pos
	local rx
	local ry

	--ハートの曲線のtripointを計算
	-- 0 <= x <= 1, 0 <= y <= 1 の部分。つまり右上
	for x = 0, 1, dx do
		y = math.sqrt(1 - x * x) + b * math.sqrt(x)
		--DEBUG.add_msg("x="..x..", y="..y)

		--半径を考慮して丸めたpointを求める
		rx = math.round(x * radius, 0)
		ry = math.round(y * radius * -1, 0)

		pos = tripoint(rx + center.x, ry + center.y, 0)
		table.insert(tripoint_list, pos)

		--x反転箇所も確保しておく
		pos = tripoint(rx * -1 + center.x, ry + center.y, 0)
		table.insert(tripoint_list, pos)
	end

	-- 0 <= x <= 1, -1 <= y <= 0 の部分。つまり右下
	for x = 1, 0, dx * -1 do
		y = (math.sqrt(1 - x * x)) * -1 + b * math.sqrt(x)
		--DEBUG.add_msg("x="..x..", y="..y)

		--半径を考慮して丸めたpointを求める
		rx = math.round(x * radius, 0)
		ry = math.round(y * radius * -1, 0)

		pos = tripoint(rx + center.x, ry + center.y, 0)
		table.insert(tripoint_list, pos)

		--x反転箇所も確保しておく
		pos = tripoint(rx * -1 + center.x, ry + center.y, 0)
		table.insert(tripoint_list, pos)
	end

	--DEBUG.add_msg("LoveFormula:end")

	return tripoint_list
end


--[[targetがヤれる状態かどうか判定]]--
function can_wife(target)
	local immobile_effect = {
		"webbed", "beartrap", "crushed", "grabbed", "in_pit", "sleep", "zapped"
	}

	if (target == nil) then
		return false
	end

	DEBUG.add_msg("wife target:"..target:disp_name())

	--ターゲットがぱんつはいてないかチェック
	if (target:wearing_something_on("bp_leg_l") and target:wearing_something_on("bp_leg_r")) then
		if (math.random(10) <= 2) then
			game.add_msg("<color_yellow>"..monster:disp_name().."瞄准了你的裤裆...</color>")
		end
		return false
	end

	DEBUG.add_msg("no wearing pants!")

	--ターゲットが身動き取れない状態かどうかチェック
	--targetが移動できない状態の場合はヤれる。適当な仕様。
	for key, value in pairs(immobile_effect) do
		if (target:has_effect(efftype_id(value))) then
			DEBUG.add_msg("immobile!")
			return true
		end
	end

	DEBUG.add_msg("can't wife.")

	return false
end

--[[イく判定]]--
function has_cum(me)
	--TODO:超適当な判定。

	local limit = 100		--v1.3から仕様変更。"lust"のintensityがこれを超えたら達する

	--"lust"のintensityを取得
	local intensity = me:get_effect_int(efftype_id("lust"))

	DEBUG.add_msg("intensity:"..intensity)

	if (intensity >= limit) then
		--"lust"を取り除き、少しだけwaitを掛ける。
		game.add_msg("<color_green>"..me:disp_name().."满足了！</color>")
		me:remove_effect(efftype_id("lust"))
		me:mod_moves(-200)

		return true
	end

	return false
end

--[[対象の体液タイプ（アイテム）を取得する。]]--
function get_ejacuate_item(me)
	local liquid

	if (me:is_player()) then
		--対象がプレイヤーなら人間の体液。
		liquid = item("h_semen", 1)

	elseif (me:is_monster()) then
		--対象がモンスターなら魔性の体液。
		liquid = item("d_cum", 1)
	end

	if not(liquid == nil) then
		liquid:set_relative_rot(0)		--そのままだとbirthdayがゲーム開始時のままなので、ここで新鮮にする
	else
		DEBUG.add_msg("ERROR:ejacuate_item is nil.")
	end

	return liquid
end



--[[↓こっからモンスター特殊攻撃処理↓]]--

--[[誘惑攻撃(近距離)]]--
function matk_seduce(monster)
	local max_range = 1		--特殊攻撃の最大射程

	DEBUG.add_msg("seduce you?")

	--攻撃しようとしているターゲットを取得
	local target = get_attackable_chara(monster, max_range)

	if (target == nil) then
		return
	end

	--HENTAI的なテキストを取得。
	local bp_names = {table.unpack(body_part_texts)}

	--TODO:尾とか羽とか、特別な部位（特質）がある場合はここでbp_namesに追加しようと思ったけど力尽きた

	local bp_text = bp_names[math.random(#bp_names)]
	local act_text = action_texts[math.random(#action_texts)]

	--HENTAI的なテキストを表示。
	game.add_msg("<color_pink>"..monster:disp_name().."对着"..target:disp_name().."的"..bp_text..act_text.."</color>")

	--状態異常"lust"と"corrupt"をtargetに与える。
	target:add_effect(efftype_id("corrupt"), game.get_time_duration(100))
	target:add_effect(efftype_id("lust"), game.get_time_duration(4))

	DEBUG.add_msg("seduce you!")

	monster:mod_moves(-100)
end

--[[誘惑攻撃(遠距離)]]--
function matk_tkiss(monster)
	local max_range = 10		--特殊攻撃の最大射程

	DEBUG.add_msg("kiss you?")

	--攻撃しようとしているターゲットを取得
	local target = get_attackable_chara(monster, max_range)

	if (target == nil) then
		return
	end

	game.add_msg("<color_pink>"..monster:disp_name().."对"..target:disp_name().."抛出飞吻！</color>")

	--状態異常"lust"と"corrupt"をtargetに与える。
	target:add_effect(efftype_id("corrupt"), game.get_time_duration(50))
	target:add_effect(efftype_id("lust"), game.get_time_duration(2))

	DEBUG.add_msg("kiss you!")

	monster:mod_moves(-50)
end


--[[脱がす攻撃]]--
function matk_stripu(monster)
	local max_range = 1			--特殊攻撃の最大射程
	local max_value = 250		--脱がしたアイテムを置くか奪うかの基準体積(mL。jsonで指定されてるvolume=1(c)は250(mL)の扱いになる。)

	--DEBUG.add_msg("strip you?")

	--ヤってる最中は脱がさない。着衣プレイっていいよね...
	if (monster:has_effect(efftype_id("dominate"))) then
		return
	end

	--攻撃しようとしているターゲットを取得
	local target = get_attackable_chara(monster, max_range)

	if (target == nil) then
		return
	end

	--ターゲットが着用しているアイテムの1つをランダムに取得。
	--get_wears(target, "bp_torso")
	--get_wears(target)
	--local item = target:i_at(-2)
	local item = get_random_wear(target)

	if (item == nil) then
		--DEBUG.add_msg("Nothing? Noooo...")
		return
	end

	--DEBUG.add_msg(item:display_name())

	--脱がす！
	--NOTE:player:takeoff()だと確認プロンプトが出てしまうので、追加→削除の流れで脱がす。
	local vol = item:volume()
	--DEBUG.add_msg("volume:"..vol:value())

	if (vol:value() > max_value) then
		--itemの体積が大きい場合はmonsterの足元に落とす。
		game.add_msg("<color_pink>"..monster:disp_name().."把"..target:disp_name().."的</color>"..item:display_name().."<color_pink>突然脱下！</color>")
		map:add_item(monster:pos(), item)
	else
		--itemの体積が十分に小さい場合（たとえば下着）はmonsterの所持品に含める。
		game.add_msg("<color_pink>"..monster:disp_name().."把"..target:disp_name().."的</color>"..item:display_name().."<color_pink>突然脱下并穿戴！</color>")
		monster:add_item(item)
	end
	target:i_rem(item)

	--DEBUG.add_msg("strip you!")

	monster:mod_moves(-100)

	return
end

--[[Wife攻撃]]--
function matk_wifeu(monster)
	local max_range = 1		--特殊攻撃の最大射程

	DEBUG.add_msg("wife you?")

	--攻撃しようとしているターゲットを取得
	local target = get_attackable_player(monster, max_range)

	--ターゲットがヤれる状態かどうかチェック
	if (not can_wife(target)) then
		monster:remove_effect(efftype_id("dominate"))
		return
	end

	--ヤる！
	if (monster:has_effect(efftype_id("dominate"))) then
		game.add_msg("<color_pink>"..monster:disp_name().."挥动着腰...</color>")
	else
		game.add_msg("<color_pink>"..monster:disp_name().."把"..target:disp_name().."摁倒并慢慢的进入到身体内...</color>")
		monster:add_effect(efftype_id("dominate"), game.get_time_duration(1), "num_bp", true)
		lost_virgin(target, false)
	end

	--状態異常"corrupt"をtargetに与える。
	target:add_effect(efftype_id("corrupt"), game.get_time_duration(200))

	--状態異常"lust"をtargetとmonster両方に与える。
	target:add_effect(efftype_id("lust"), game.get_time_duration(8))

	--monsterの方は相手の器用の分だけプラス。
	--こう何というか、先にイった方が負けみたいなバトルを繰り広げたいけどバランスをどうすればいいんだ
	monster:add_effect(efftype_id("lust"), game.get_time_duration(8 + target.dex_cur))


	--イく！
	if (has_cum(target)) then
		local liquid = get_ejacuate_item(target)
		map:add_item(target:pos(), liquid)
	end
	if (has_cum(monster)) then
		local liquid = get_ejacuate_item(monster)
		map:add_item(monster:pos(), liquid)

		--一時的に友好的に近づける。でないとrape loopに嵌ってしまう...
		--TODO:それでも複数に囲まれると死ぬまで嬲られるのをどうにかしたい
		monster.anger = monster.anger - 50
		monster.friendly = monster.friendly + 50
		monster.morale = monster.morale - 30
	end

	--モンスターが次に取る行動をLUA側で制御する事はできないっぽい？ので
	--この特殊攻撃のクールダウンを0にセットする事で連続行動を促す
	--monster:set_special("WIFE_U", 0)
	--monster:process_turn()
	--と思ったがそんな事はなかったぜ！set_special()は呼び出しても元側でちゃんとセットできてないっぽいです

	DEBUG.add_msg("wife you!")

	target:mod_moves(-100)
	monster:mod_moves(-100)

	return
end

--[[ハート炎攻撃]]--
function matk_loveflame(monster)
	local max_range = 15		--特殊攻撃の最大射程

	DEBUG.add_msg("love flame?")

	--攻撃しようとしているターゲットを取得
	local target = get_attackable_target(monster, max_range)

	if (target == nil) then
		return
	end

	local tripoint_list = LoveFormula(target:pos(), 10)

	for key, value in pairs(tripoint_list) do
		--DEBUG.add_msg("key:"..key)
		--DEBUG.add_msg("value:"..value.x..", "..value.y)
		map:add_field(value, "fd_fire", 10, game.get_time_duration(10))
		--g:draw()
		--g:draw_ter(value)
	end

	game.add_msg(monster:disp_name().."咏唱了咒语、"..target:disp_name().."的周围燃烧了起来！")

	monster:mod_moves(-200)

	DEBUG.add_msg("love flame!")
end


--[[睡眠攻撃]]--
function matk_sleep_magic(monster)
	local max_range = 20		--特殊攻撃の最大射程
	local magic_cost = 3		--攻撃に必要な魔法チャージ数

	DEBUG.add_msg("sleep you?")

	--攻撃しようとしているターゲットを取得
	local target = get_attackable_player(monster, max_range)

	if (target == nil) then
		return
	end

	--ターゲットが既に効果に掛かっている、あるいは寝ているなら何もしない。
	if (target:has_effect(efftype_id("magic_sleepy")) or target:has_effect(efftype_id("sleep"))) then
		--DEBUG.add_msg("Welp, slept already.")
		return
	end

	local timecount = monster:get_effect_dur(efftype_id("spell_charge"))
	--DEBUG.add_msg("timecount:"..timecount:get_turns())

	if (timecount:get_turns() < magic_cost) then
		--DEBUG.add_msg("Charging...")
		spell_charge(monster)
		return
	else
		--DEBUG.add_msg("Let's cast!")
		monster:remove_effect(efftype_id("spell_charge"))
	end

	--必要なチャージ数が溜まったら攻撃！
	if (player:sees(monster:pos())) then
		game.add_msg(monster:disp_name().."指着"..target:disp_name().."并诅咒着！")
	end
	target:add_effect(efftype_id("magic_sleepy"), game.get_time_duration(900))

	monster:mod_moves(-500)

	DEBUG.add_msg("sleep you!")

end

function spell_charge(monster)
	--DEBUG.add_msg("spell_charge")

	--monster:add_effect(efftype_id("spell_charge"), game.get_time_duration(300))

	if (player:sees(monster:pos())) then
		if (monster:has_effect(efftype_id("spell_charge"))) then
			game.add_msg(monster:disp_name().."施了一个咒语...")
		else
			game.add_msg(monster:disp_name().."开始咏唱咒语了。")
		end

	else
		game.add_msg("听到了谁的低语...")
	end

	monster:add_effect(efftype_id("spell_charge"), game.get_time_duration(1), "num_bp", true)

	monster:mod_moves(-250)
end

--[[露出攻撃。...攻撃？]]--
function matk_expose(monster)
	local max_range = 30		--特殊攻撃の最大射程

	DEBUG.add_msg("expose?")

	--周辺に存在するplayerをすべて取得する
	local player_list = get_players()
	local target_list = {}

	local dist
	for key, value in pairs(player_list) do

		DEBUG.add_msg("key:"..key)
		DEBUG.add_msg("value:"..value:disp_name())

		dist = game.distance(monster:posx(), monster:posy(), value:posx(), value:posy())		--line.cppを参照。

		--対象が射程内であればリストに追加する
		if (dist <= max_range) then
			table.insert(target_list, value)
		end

	end

	--対象が存在するなら
	if (#target_list > 0) then
		local rnd = math.random(3)

		if (rnd == 1) then
			add_msg(monster:disp_name().."一脱衣服，就开始向周围的环境展示娇艳的裸体！", H_COLOR.PINK)
		elseif (rnd == 2) then
			add_msg(monster:disp_name().."炫耀自己，并用甜美的声音邀请其他人！", H_COLOR.PINK)
		else
			add_msg(monster:disp_name().."把手放在胯下，发出消失理智般的声音！", H_COLOR.PINK)
		end

		monster:mod_moves(-500)

		for key, value in pairs(target_list) do
			--対象にモンスターの姿が見ているなら"lust"と"corrupt"を与える。
			if (value:sees(monster:pos())) then
				value:add_effect(efftype_id("corrupt"), game.get_time_duration(600))
				value:add_effect(efftype_id("lust"), game.get_time_duration(24))
			end
		end
	end

	DEBUG.add_msg("expose!")
end

