# cdda-tool-bundle
A mod for Cataclysm: Dark Days Ahead. Adds the ability for most tools to be attached to a belt clip and provides a primitive canvas bundle to keep your tools organized.
