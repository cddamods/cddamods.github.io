此版本為百度貼吧cataclysmdda吧友993499094分享之版本
來源：https://tieba.baidu.com/p/5308708900