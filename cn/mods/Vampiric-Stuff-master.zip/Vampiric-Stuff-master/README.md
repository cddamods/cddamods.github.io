# Vampiric-Stuff

### How to install the mod:

1. Extract **Vampiric-Stuff-master**.
2. Put the _vamp_stuff_ and _vamp_stuff+arcana_ into the mod folder of CDDA.
3. Done. Enjoy the mod!



### How to activate Vampiric Stuff + Arcana Mod Extension:

1. Get the latest **Arcana and Magic Items** at https://github.com/chaosvolt/cdda-arcana-mod
2. Put the _Arcana_ to the mod folder of CDDA.
3. Activate _Vampiric Stuff + Arcana Mod Extension_ on world creation.
4. Done. Enjoy the new features!



### Additional info:

Peek inside the _vamp_stuff_ mod folder for changelogs and other informational texts.
